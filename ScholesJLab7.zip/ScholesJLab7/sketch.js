//arrays for each conference in the NFL
let NFC = ["Arizona", "Atlanta", "Carolina", "Chicago", "Dallas", "Detroit", "Green Bay", "Los Angeles R.", "Minnesota", "New Orleans", "New York G.", "Philadelphia", "San Francisco", "Seattle", "Tampa Bay", "Washington"];
let AFC = ["Baltimore", "Buffalo", "Cincinnati", "Cleveland", "Denver", "Houston", "Indianapolis", "Jacksonville", "Kansas City", "Las Vegas", "Los Angeles C.", "Miami", "New England", "New York J.", "Pittsburgh","Tennessee"];
let SuperBowl = [];

function setup() 
  {
    createCanvas(400, 400);
    background(220);
    
    //picks a team from each conference randomly
    let team1 = Math.floor(random(0,NFC.length));
    let team2 = Math.floor(random(0,AFC.length));
    console.log(team1,team2);
    
    //adds each picked team to SuperBowl array
    SuperBowl.push(NFC[team1]);
    SuperBowl.push(AFC[team2]);
    console.log(SuperBowl);
    
    //Displays text of SuperBowl matchup
    text("The SuperBowl matchup for 2026 is: \nNFC:" + NFC[team1] + ", and \nAFC:" + AFC[team2],115,200);
  }
