let img1;

function preload(){
  img1 = loadImage('./assets/download.png');
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  scale(1.5,2.2);
  image(img1,0,0);
  scale(1.0);
  textSize(22);
  fill("orange");
  stroke(0);
  strokeWeight(3);
  textFont("Modern Sans");
  text("Happy Fall!",85,100);
}