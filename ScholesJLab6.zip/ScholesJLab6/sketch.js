let rectPosition = [];
let num = 10;
value = ["red", "orange", "yellow", "green", "indigo", "violet"];
function setup() 
{
  createCanvas(400, 400);
  for(let i=0; i<num; i++)
  {
    rectPosition[i] = [];
    for (let p=0; p<2; p++) 
      {
        rectPosition[i][p] = -100;
      }
  }
  console.log(rectPosition);
}
function draw() 
  {
    background(0);
    fill(255);
    noStroke();
    rectPosition[rectPosition.length-1][0] = mouseX;
    rectPosition[rectPosition.length-1][1] = mouseY;
    for(let r=0;r<rectPosition.length-1;r++)
    {
      for(let s = 0; s<2; s++)
        {
      rectPosition[r][s] = rectPosition[r+1][s];
        }  
    }
  for(let i=0; i<num; i++)
    {
    let choice = random(value);
    fill(choice);
    rect(rectPosition[i][0],rectPosition[i][1],40,40);
    }
  }